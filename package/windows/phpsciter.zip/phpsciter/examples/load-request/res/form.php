<?php
var_dump($_GET);
?>
<a href="index2.php">return2</a>