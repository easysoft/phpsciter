<?php
function A()
{
}

class A{
}