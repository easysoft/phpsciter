<?php
echo "hello word<br/>";